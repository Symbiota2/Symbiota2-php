INSERT INTO taxa(TID, RankId, SciName, UnitName1, SecurityStatus, InitialTimeStamp) VALUES (1, 1, 'Organism', 'Organism', 0, '2018-05-15 12:01:01'),
 (2, 10, 'Monera', 'Monera', 0, '2018-05-15 12:01:01'),
 (3, 10, 'Protista', 'Protista', 0, '2018-05-15 12:01:01'),
 (4, 10, 'Plantae', 'Plantae', 0, '2018-05-15 12:01:01'),
 (5, 10, 'Fungi', 'Fungi', 0, '2018-05-15 12:01:01'),
 (6, 10, 'Animalia', 'Animalia', 0, '2018-05-15 12:01:01')
