INSERT INTO taxa(TID, RankId, SciName, UnitName1) VALUES (1, 1, 'Organism', 'Organism'),
 (2, 10, 'Monera', 'Monera'),
 (3, 10, 'Protista', 'Protista'),
 (4, 10, 'Plantae', 'Plantae'),
 (5, 10, 'Fungi', 'Fungi'),
 (6, 10, 'Animalia', 'Animalia')