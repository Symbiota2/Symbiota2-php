INSERT INTO userroles(uid, role, initialtimestamp) VALUES (1, 'SuperAdmin', '2018-05-15 12:01:01')
