INSERT INTO schemaversion(id, versionnumber, modifiedtimestamp) VALUES (1, '1.0', '2019-01-11 14:06:13'),
 (2, '1.1', '2019-01-11 14:06:43'),
 (3, '2.0', '2019-01-11 14:06:43')
