INSERT INTO kmchardependence(CID, kmcsid) VALUES (12, 557),
 (170, 636),
 (16, 240),
 (27, 445)
