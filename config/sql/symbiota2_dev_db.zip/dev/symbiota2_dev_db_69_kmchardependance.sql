INSERT INTO kmchardependance(CID, CIDDependance, CSDependance, InitialTimeStamp) VALUES (12, 11, '4', '2019-01-12 12:09:58'),
 (170, 14, '5', '2019-01-12 12:13:18'),
 (16, 15, '2', '2019-01-12 12:09:58'),
 (27, 26, '3', '2019-01-12 12:09:58')