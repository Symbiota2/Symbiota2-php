INSERT INTO tmtraittaxalink(traitid, tid) VALUES (1, 2075),
 (2, 2075),
 (3, 2075),
 (4, 2075)