DELETE FROM userroles
