DELETE FROM configurations
