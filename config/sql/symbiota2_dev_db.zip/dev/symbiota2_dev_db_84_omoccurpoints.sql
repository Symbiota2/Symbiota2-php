INSERT INTO omoccurpoints (occid,point,initialtimestamp)
SELECT occid,ST_GeomFromText(CONCAT('POINT(',decimalLatitude,' ',decimalLongitude,')'), 4326),NOW()
FROM omoccurrences WHERE decimalLatitude IS NOT NULL AND decimalLongitude IS NOT NULL;
