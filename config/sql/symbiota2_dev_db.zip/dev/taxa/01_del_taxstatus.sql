DELETE FROM taxstatus
