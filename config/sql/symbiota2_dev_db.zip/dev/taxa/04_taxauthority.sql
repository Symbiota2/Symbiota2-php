INSERT INTO taxauthority(taxauthid, isprimary, name, description, editors, contact, email, url, notes, isactive, initialtimestamp) VALUES (1, 1, 'Central Taxonomic Thesaurus', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2019-01-11 21:47:26'),
 (2, 0, 'ITIS Thesaurus', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2019-01-11 21:47:56'),
 (3, 0, 'MycoBank', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2019-01-12 14:25:32')
