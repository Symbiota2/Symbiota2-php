DELETE FROM taxauthority
