INSERT INTO kmchartaxalink(CID, tid) VALUES (545, 1290),
 (545, 1488)