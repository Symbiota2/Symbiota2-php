INSERT INTO kmdescrdeletions(tid, CS, Modifier, X, TXT, Inherited, Source, Seq, Notes, InitialTimeStamp, DeletedBy, DeletedTimeStamp, PK, CID, kmcsid) VALUES (1044, '4', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2005-12-31 23:00:01', 'keyadmin', '2019-01-12 12:19:46', 638, 1, 555),
 (2838, '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-08-22 10:55:42', 'keyadmin', '2019-01-12 12:19:46', 900, 24, 443),
 (2669, '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-08-22 15:01:29', 'keyadmin', '2019-01-12 12:19:46', 901, 18, 440),
 (3342, '2', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2005-12-31 23:00:01', 'keyadmin', '2019-01-12 12:19:46', 1196, 1, 228),
 (1889, '2', NULL, NULL, NULL, NULL, 'ASDM', NULL, NULL, '2006-12-26 00:44:07', 'keyeditor', '2019-01-12 12:19:46', 1197, 1, 228),
 (1175, '2', NULL, NULL, NULL, NULL, 'ASDM', NULL, NULL, '2006-12-25 22:05:06', 'keyeditor', '2019-01-12 12:19:46', 1198, 1, 228),
 (1290, '4', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2006-12-26 00:44:04', 'keyeditor', '2019-01-12 12:19:46', 1202, 1, 555),
 (39, '4', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2005-12-31 23:00:01', 'keyeditor', '2019-01-12 12:19:46', 1203, 1, 555),
 (1901, '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-05-25 01:21:52', 'keyadmin', '2019-01-12 12:19:46', 1237, 51, 266);
