INSERT INTO kmdescrdeletions(TID, CID, CS, Modifier, X, TXT, Inherited, Source, Seq, Notes, InitialTimeStamp, DeletedBy, DeletedTimeStamp, PK) VALUES (1044, 1, '4', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2005-12-31 23:00:01', 'keyadmin', '2019-01-12 12:19:46', 638),
 (2838, 24, '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-08-22 10:55:42', 'keyadmin', '2019-01-12 12:19:46', 900),
 (2669, 18, '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-08-22 15:01:29', 'keyadmin', '2019-01-12 12:19:46', 901),
 (3342, 1, '2', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2005-12-31 23:00:01', 'keyadmin', '2019-01-12 12:19:46', 1196),
 (1889, 1, '2', NULL, NULL, NULL, NULL, 'ASDM', NULL, NULL, '2006-12-26 00:44:07', 'keyeditor', '2019-01-12 12:19:46', 1197),
 (1175, 1, '2', NULL, NULL, NULL, NULL, 'ASDM', NULL, NULL, '2006-12-25 22:05:06', 'keyeditor', '2019-01-12 12:19:46', 1198),
 (1290, 1, '4', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2006-12-26 00:44:04', 'keyeditor', '2019-01-12 12:19:46', 1202),
 (39, 1, '4', NULL, NULL, NULL, NULL, 'ASU Herbarium', NULL, NULL, '2005-12-31 23:00:01', 'keyeditor', '2019-01-12 12:19:46', 1203),
 (1901, 51, '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-05-25 01:21:52', 'keyadmin', '2019-01-12 12:19:46', 1237)