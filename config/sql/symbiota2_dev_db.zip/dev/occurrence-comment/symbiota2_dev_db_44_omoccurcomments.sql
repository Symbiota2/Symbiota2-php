INSERT INTO omoccurcomments(comid, occid, comment, createduid, reviewstatus, parentcomid, initialtimestamp) VALUES (1, 4060, 'test comment', 20, 1, NULL, '2019-01-12 12:51:51')
