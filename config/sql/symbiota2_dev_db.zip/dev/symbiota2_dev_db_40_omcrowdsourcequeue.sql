INSERT INTO omcrowdsourcequeue(idomcrowdsourcequeue, omcsid, occid, reviewstatus, uidprocessor, points, isvolunteer, notes, initialtimestamp) VALUES (1, 1, 4274, 5, 22, NULL, 1, NULL, '2019-01-12 12:41:51'),
 (2, 1, 4276, 5, 22, NULL, 1, NULL, '2019-01-12 12:41:51'),
 (3, 1, 4277, 5, 23, NULL, 1, NULL, '2019-01-12 12:41:51'),
 (4, 2, 4428, 10, 23, 2, 1, NULL, '2019-01-12 12:41:51'),
 (5, 2, 4532, 0, 23, NULL, 1, NULL, '2019-01-12 12:41:51')