INSERT INTO tmtraitdependencies(traitid, parentstateid, initialtimestamp) VALUES (2, 1, '2019-01-12 10:58:09'),
 (3, 4, '2019-01-12 10:58:09'),
 (4, 5, '2019-01-12 10:58:09')